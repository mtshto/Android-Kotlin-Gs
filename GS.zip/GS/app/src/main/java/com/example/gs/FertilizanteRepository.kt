package com.example.gs
import kotlin.random.Random

class FertilizanteRepository {

    private val organicos = FertilizanteType.organicos
    private val quimicos = FertilizanteType.quimicos
    private val liberacao = FertilizanteType.liberacao

    private val listPhrases: List<Fertilizante> = listOf(
        Fertilizante("Considere utilizar fertilizantes orgânicos, como esterco ou compostagem, para melhorar a saúde do solo e fornecer nutrientes de forma natural às suas plantas.", organicos),
        Fertilizante("Os fertilizantes orgânicos são uma opção sustentável e amigável ao meio ambiente, proporcionando uma nutrição equilibrada para suas plantas.", organicos),
        Fertilizante("Experimente utilizar farinha de ossos como fertilizante orgânico, pois ela é rica em fósforo, um nutriente essencial para o desenvolvimento saudável das raízes das plantas.", organicos),
        Fertilizante("Ao optar por fertilizantes orgânicos, você promove a biodiversidade do solo, estimula a atividade microbiana e ajuda a construir um ambiente favorável para o crescimento das suas plantas.", organicos),
        Fertilizante("Os fertilizantes químicos podem ser uma opção eficiente para corrigir deficiências nutricionais nas suas plantas, mas lembre-se de seguir as dosagens recomendadas para evitar danos.", quimicos),
        Fertilizante("Utilize fertilizantes químicos de liberação rápida para estimular o crescimento vigoroso das plantas, especialmente durante períodos de alta demanda nutricional.", quimicos),
        Fertilizante("Aplique fertilizantes químicos com equilíbrio de nutrientes, como NPK (nitrogênio, fósforo e potássio), para fornecer às suas plantas os elementos necessários para um desenvolvimento saudável.", quimicos),
        Fertilizante("Lembre-se de acompanhar de perto os efeitos dos fertilizantes químicos e ajustar as doses conforme necessário, para evitar excessos e possíveis danos às plantas.", quimicos),
        Fertilizante("Considere utilizar fertilizantes de liberação lenta para garantir uma nutrição contínua e gradual às suas plantas ao longo do tempo.", liberacao),
        Fertilizante("Os fertilizantes de liberação lenta são ideais para cultivos de longa duração, como árvores frutíferas e arbustos, proporcionando um suprimento constante de nutrientes.", liberacao),
        Fertilizante("Ao utilizar fertilizantes de liberação lenta, você reduz a frequência de aplicações e garante uma absorção eficiente dos nutrientes pelas raízes das plantas.", liberacao),
        Fertilizante("Lembre-se de seguir as instruções de uso dos fertilizantes de liberação lenta e aplicá-los de acordo com as necessidades específicas das suas plantas para obter melhores resultados.", liberacao),
    )

    // Obtém frase aleatória de acordo com o filtro
    fun getPhrase(value: FertilizanteType): Fertilizante {
        val filtered = if (value == organicos) {
            listPhrases.filter { it.type == value }
        } else {
            listPhrases.filter { it.type == value || it.type == organicos }
        }

        if (filtered.isEmpty()) {
            throw NoSuchElementException("Array contains no element matching the predicate.")
        }

        val rand = Random.nextInt(filtered.size)

        return filtered[rand]
    }
}

