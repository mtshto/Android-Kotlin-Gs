package com.example.gs

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.navigation.fragment.findNavController
import com.example.gs.databinding.FragmentFertilizanteBinding

class FertilizanteFragment : Fragment() {

    private lateinit var bind: FragmentFertilizanteBinding
    private var fertilizanteType = FertilizanteType.organicos

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bind = FragmentFertilizanteBinding.inflate(inflater, container, false)
        return bind.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        bind.milho.setOnClickListener {
            bind.milho.isChecked = true
            bind.soja.isChecked = false
            bind.arroz.isChecked = false
        }

        // Ouvinte de clique para o switch Soja
        bind.soja.setOnClickListener {
            bind.milho.isChecked = false
            bind.soja.isChecked = true
            bind.arroz.isChecked = false
        }

        // Ouvinte de clique para o switch Arroz
        bind.arroz.setOnClickListener {
            bind.milho.isChecked = false
            bind.soja.isChecked = false
            bind.arroz.isChecked = true
        }

        bind.btnFertilizante.setOnClickListener {
            if (bind.milho.isChecked) {
                navigateToFertilizanteActivity("milho")
            } else if (bind.arroz.isChecked) {
                navigateToFertilizanteActivity("arroz")
            } else if (bind.soja.isChecked) {
                navigateToFertilizanteActivity("soja")
            }
        }

        bind.btnVoltar.setOnClickListener {
            findNavController().navigate(R.id.action_fertilizanteFragment_to_escolhasFragment)
        }
    }

    private fun navigateToFertilizanteActivity(crop: String) {
        val intent = Intent(requireContext(), FertilizanteActivity::class.java)
        intent.putExtra("PHRASE_TYPE", fertilizanteType.ordinal)
        intent.putExtra(crop, true)
        register.launch(intent)
    }

    private val register = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.let { data ->
                val phraseExtra = data.getParcelableExtra<Fertilizante>("FERTILIZANTE_ITEM")
                phraseExtra?.let {
                    bind.linearLayout.visibility = View.VISIBLE
                }
            }
        }
    }
}
