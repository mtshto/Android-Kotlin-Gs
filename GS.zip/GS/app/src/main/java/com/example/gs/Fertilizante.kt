package com.example.gs

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Fertilizante(
    val descricao: String,
    val type: FertilizanteType
) : Parcelable
