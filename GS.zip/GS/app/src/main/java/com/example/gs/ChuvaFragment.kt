package com.example.gs

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.TextView
import androidx.navigation.fragment.findNavController
import com.example.gs.databinding.FragmentChuvaBinding
import java.util.*


class ChuvaFragment : Fragment() {

    lateinit var bind : FragmentChuvaBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_chuva, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bind = FragmentChuvaBinding.bind(view)

        bind.btnChuvas.setOnClickListener {
            // Obter os TextViews pelos seus IDs
            val txtNorte = view.findViewById<TextView>(R.id.txtNorte)
            val txtNordeste = view.findViewById<TextView>(R.id.txtNordeste)
            val txtCentroOeste = view.findViewById<TextView>(R.id.txtCentroOeste)
            val txtSudeste = view.findViewById<TextView>(R.id.txtSudeste)
            val txtSul = view.findViewById<TextView>(R.id.txtSul)

            // Definir textos aleatórios para os TextViews
            txtNorte.text = gerarTextoAleatorio()
            txtNordeste.text = gerarTextoAleatorio()
            txtCentroOeste.text = gerarTextoAleatorio()
            txtSudeste.text = gerarTextoAleatorio()
            txtSul.text = gerarTextoAleatorio()
        }

        bind.btnVoltar.setOnClickListener {
            findNavController().navigate(R.id.action_chuvasFragment_to_escolhasFragment)
        }
    }

    private fun gerarTextoAleatorio(): String {
        val random = Random()
        val quantidadeChuva = random.nextInt(351) // Gera um número aleatório entre 0 e 350
        return "@string/txtChuvas $quantidadeChuva mm"
    }



}