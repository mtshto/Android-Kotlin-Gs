package com.example.gs

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.example.gs.databinding.FragmentEscolhasBinding
import com.example.gs.databinding.FragmentHomeBinding
import com.example.gs.databinding.FragmentProdutividadeBinding


class ProdutividadeFragment : Fragment() {


    lateinit var bind : FragmentProdutividadeBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return inflater.inflate(R.layout.fragment_produtividade, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bind = FragmentProdutividadeBinding.bind(view)

        // Definir os valores de multiplicação para cada switch
        val milhoValue = 2
        val sojaValue = 3
        val arrozValue = 4

        // Ouvinte de clique para o switch Milho
        bind.milho.setOnClickListener {
            bind.milho.isChecked = true
            bind.soja.isChecked = false
            bind.arroz.isChecked = false
        }

        // Ouvinte de clique para o switch Soja
        bind.soja.setOnClickListener {
            bind.milho.isChecked = false
            bind.soja.isChecked = true
            bind.arroz.isChecked = false
        }

        // Ouvinte de clique para o switch Arroz
        bind.arroz.setOnClickListener {
            bind.milho.isChecked = false
            bind.soja.isChecked = false
            bind.arroz.isChecked = true
        }

        bind.btnCalcular.setOnClickListener {
            // Obter os valores dos inputs do usuário
            val input01 = bind.input01.text.toString().toIntOrNull() ?: 0
            val input02 = bind.input02.text.toString().toIntOrNull() ?: 0

            // Verificar qual switch está selecionado e calcular o resultado
            val switchValue = when {
                bind.milho.isChecked -> milhoValue
                bind.soja.isChecked -> sojaValue
                bind.arroz.isChecked -> arrozValue
                else -> 0
            }

            // Calcular o resultado multiplicando os inputs pelos valores do switch
            val resultado = input01 * switchValue + input02

            // Exibir o resultado no textView
            bind.txtResultado.text = resultado.toString()
        }

        bind.btnVoltar.setOnClickListener {
            findNavController().navigate(R.id.action_produtividadeFragment_to_escolhasFragment)
        }
    }



}