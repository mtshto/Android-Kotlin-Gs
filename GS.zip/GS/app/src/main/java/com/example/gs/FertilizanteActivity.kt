package com.example.gs

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.annotation.RequiresApi
import com.example.gs.databinding.ActivityFertilizanteBinding

class FertilizanteActivity : AppCompatActivity() {

    private lateinit var bind: ActivityFertilizanteBinding
    private lateinit var fertilizante: Fertilizante

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind = ActivityFertilizanteBinding.inflate(layoutInflater)
        setContentView(bind.root)

        val type = intent.getIntExtra("PHRASE_TYPE", -1)
        val enumPhrase = FertilizanteType.values().first { it.ordinal == type }
        fertilizante = FertilizanteRepository().getPhrase(enumPhrase)

        bind.frases.text = fertilizante.descricao

        // Obter o valor do Switch selecionado
        val selectedCrop = when {
            intent.getBooleanExtra("milho", false) -> "milho"
            intent.getBooleanExtra("arroz", false) -> "arroz"
            intent.getBooleanExtra("soja", false) -> "soja"
            else -> ""
        }

        // Definir a imagem correspondente
        when (selectedCrop) {
            "milho" -> bind.imageView.setImageResource(R.drawable.milho)
            "arroz" -> bind.imageView.setImageResource(R.drawable.arroz)
            "soja" -> bind.imageView.setImageResource(R.drawable.soja)
        }

        bind.voltar.setOnClickListener {
            Intent().apply {
                putExtra("FERTILIZANTE_ITEM", fertilizante)
                setResult(RESULT_OK, this)
            }
            this.finish()
        }
    }

    override fun onBackPressed() {
        Intent().apply {
            putExtra("PHRASE_ITEM", fertilizante)
            setResult(RESULT_OK, this)
        }
        this.finish()
    }
}



