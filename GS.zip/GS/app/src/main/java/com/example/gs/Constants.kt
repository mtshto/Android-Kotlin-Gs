package com.example.gs

object Constants {

    var currentTheme = R.style.Theme_GS
    private const val ACTUAL = R.style.Theme_GS
    private const val CUSTOM = R.style.badGreen

    fun switchTheme() {
        currentTheme = when (currentTheme) {
            ACTUAL -> CUSTOM
            CUSTOM -> ACTUAL
            else -> -1
        }
    }

    fun getThemeName() = when (currentTheme) {
        ACTUAL -> "Mudar tema"
        CUSTOM -> "Voltar tema"
        else -> "Mudar tema"
    }
}